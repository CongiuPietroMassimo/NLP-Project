python verification_scorer.py \
 --actual_file data/Arabic_dev.json \
 --pred_file submission_samples/KGAT_zeroShot_verification_Arabic_dev.json \
 --out_file  KGAT_zeroShot_dev_fold5_results.csv
