python retrieval_scorer.py --pred_file submission_samples/KGAT_zeroShot_evidence_Arabic_dev.txt \
      --actual_file data/dev_qrels.txt \
      --output_file KGAT_zeroShot_retrieval_Arabic_dev.csv
